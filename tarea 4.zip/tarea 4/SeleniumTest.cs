using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace AutoTest4
{
    public class Tests
    {
        IWebDriver driver;
        IWebElement webElement;

        [SetUp]
        public void Setup()
        {
            //Finds the driver directory dinamically
            string driverPath = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;

            //Creates a new chrome driver, then executes tests on google chrome
            driver = new ChromeDriver(driverPath + @"\drivers\");
        }

        [Test]
        public void LogInTest()
        {
            
            //Opens the web page by its URL
            driver.Navigate().GoToUrl("https://www.amazon.com/-/es/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
            Thread.Sleep(1000);

            //Finds the element we want to click, in this case the log in button
            webElement = driver.FindElement(By.Id("ap_email"));
            Thread.Sleep(1000);

            //Performing
            webElement.SendKeys(" ");
            ClickButtonById("continue");
            TakeScreenShot("EmptyEmail");

            Thread.Sleep(1000);

            //Filling out fields
            webElement.SendKeys("correo@electronico.com");
            TakeScreenShot("Email");
            ClickButtonById("continue");
            Thread.Sleep(1000);

            //No password
            driver.FindElement(By.Id("signInSubmit")).Click();
            TakeScreenShot("EmptyPassword");
            Thread.Sleep(1000);


            //Filling out password
            webElement = driver.FindElement(By.Id("ap_password"));
            webElement.SendKeys("contrase�a");
            TakeScreenShot("EmptyMail");
            ClickButtonById("signInSubmit");
            Thread.Sleep(1000);

            LoadPerformance();

        }
        
        public void LoadPerformance()
        {
            Thread.Sleep(500);
            TakeScreenShot("PageAfter 0.5 seconds");

            Thread.Sleep(1000);
            TakeScreenShot("PageAfter 1.5 seconds");

            Thread.Sleep(1000);
            TakeScreenShot("PageAfter 2.5 seconds");
        }


        [Test]
        public void CartTest()
        {
            LogInTest();

            //Look for a laptop stand

            FindElementById("twotabsearchtextbox");
            WriteText("laptop stand");
            ClickButtonById("nav-search-submit-button");

            //Click the laptop stand
            ClickButtonByXPath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span");
            TakeScreenShot("StandSearch");

            //Add it to the cart
            ClickButtonById("add-to-cart-button");
            
            //Cart page
            ClickButtonById("nav-cart");
            TakeScreenShot("AddedItemInCart");

            //Item deleted
            ClickButtonByXPath("//*[@id=\"sc-active-C9e8130ed-7607-4a21-85c4-f7500015be88\"]/div[4]/div/div[3]/div[1]/span[2]/span/input");
            TakeScreenShot("ItemDeletedFromCart");
        }

        [Test]
        public void AddressVerification()
        {
            LogInTest();

            //Click on account list
            ClickButtonById("nav-link-accountList");

            //Click on user's address
            ClickButtonByXPath("//*[@id=\"a-page\"]/div[2]/div/div[3]/div[1]/a/div/div");

            //Click on add address
            ClickButtonById("ya-myab-plus-address-icon");

            //Click on contry dropdown menu
            ClickButtonByXPath("//*[@id=\"address-ui-widgets-countryCode\"]/span/span");
            
            //Click on dominican republic
            ClickButtonById("address-ui-widgets-countryCode-dropdown-nativeId_190");
            
            //Find name text box
            FindElementById("address-ui-widgets-enterAddressFullName");
            
            //Add name
            WriteText("Nombre");
            
            //Add address
            FindElementById("address-ui-widgets-enterAddressLine1");
            WriteText("Direccion");
            FindElementById("address-ui-widgets-enterAddressLine2");
            WriteText("#12");

            //Add city
            FindElementById("address-ui-widgets-enterAddressCity");
            WriteText("Ciudad");

            //Add province
            FindElementById("address-ui-widgets-enterAddressStateOrRegion");
            WriteText("Provincia");
            
            //Add zip code
            FindElementById("address-ui-widgets-enterAddressPostalCode");
            WriteText("Codigopostal");
            
            //Add address
            ClickButtonByXPath("//*[@id=\"address-ui-widgets-form-submit-button\"]/span/input");
            TakeScreenShot("AddressData");

            //Content verification
            Assert.IsTrue(driver.PageSource.Contains("Nombre"));
            Assert.IsTrue(driver.PageSource.Contains("Calle"));
            Assert.IsTrue(driver.PageSource.Contains("# de casa"));
            Assert.IsTrue(driver.PageSource.Contains("ciudad"));
            Assert.IsTrue(driver.PageSource.Contains("provincia"));
            Assert.IsTrue(driver.PageSource.Contains("codigopostal"));

        }


        public void TakeScreenShot(string imageName)
        {
            Screenshot screenshot = ((ITakesScreenshot)driver).GetScreenshot();
            screenshot.SaveAsFile("C:\\Users\\Freddy Villar\\Desktop\\PROGRAMACION 3 (5)\\SEMANA 11\\AutoTest4\\ScreenShots\\"+imageName+".png");

        }

        public void ClickButtonById(string elementId) => driver.FindElement(By.Id(elementId)).Click();
        public void ClickButtonByName(string elementName) => driver.FindElement(By.Id(elementName)).Click();
        public void ClickButtonByXPath(string elementXPath) => driver.FindElement(By.XPath(elementXPath)).Click();
        public void FindElementById(string elementId) => webElement = driver.FindElement(By.Id(elementId));
        public void FindElementByName(string elementName) => webElement = driver.FindElement(By.Name(elementName));
        public void FindElementByXPath(string elementXPath) => webElement = driver.FindElement(By.XPath(elementXPath));
        public void WriteText(string text) => webElement.SendKeys(text);


        //[TearDown]
        //public void Close()
        //{
        //    driver.Close();
        //}

    }
}